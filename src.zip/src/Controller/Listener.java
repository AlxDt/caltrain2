/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Sync.Signal;
import Model.Sync.TrainMoveSignal;
import java.util.concurrent.LinkedBlockingQueue;
import javafx.scene.canvas.GraphicsContext;
import View.Interface.UI;
import java.util.HashMap;

/**
 *
 * @author user
 */
public class Listener {

    // Train listener
    public synchronized static void trainListener(UI dispatcher, GraphicsContext gc, LinkedBlockingQueue updateQueue) {
        new Thread(() -> {
            // The trains's position
            HashMap trainPositionMap = CalTrain2.trainPositionMap;

            // Listen indefinitely
            while (true) {
                // Wait for a signal that a train has moved
                Signal signal = (Signal) updateQueue.poll();

                // What kind of signal?
                if (signal instanceof TrainMoveSignal) {
                    // Train has moved
                    // Update that train's position
                    trainPositionMap.put(((TrainMoveSignal) signal).getTrain(), ((TrainMoveSignal) signal).getNewLocation());

                    // Redraw UI canvas
                    UI.redrawUI(gc, trainPositionMap);
                }
            }
        }).start();
    }
}
