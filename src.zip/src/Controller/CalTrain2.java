/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Core.FreeSegment;
import Model.Core.Passenger;
import Model.Core.Segment;
import Model.Core.Station;
import Model.Core.Train;
import Model.Sync.TrainMoveSignal;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author user
 */
public class CalTrain2 {

    // Number of stations
    public static final int NUM_STATIONS = 8;

    // Number of maximum trains
    public static final int MAX_TRAINS = 16;

    // Number of (initial) passengers
    public static final int INITIAL_PASSENGERS = 10;

    // Number of trains dispatched
    public static int trainsDispatched = 0;

    // The system segments
    private Segment[] segments;

    // The train fleet
    private Train[] fleet;

    // The runnable train fleet
    private Thread[] trains;

    // Update queue
    private final LinkedBlockingQueue updateQueue;

    // The train position map
    public static HashMap<Train, Segment> trainPositionMap = new HashMap<>();

    // Constructor
    public CalTrain2(LinkedBlockingQueue updateQueue) {
        this.updateQueue = updateQueue;
    }

    public void start() {
        // Set the infrastructure up
        segments = setInfrastructure(NUM_STATIONS);

        // Set the train fleet up
        fleet = setTrains(MAX_TRAINS);

        // Make the fleet runnable
        trains = prepareTrains();

        // Operation loop
        System.out.println("Starting services...");

        // Passenger creator with destination and origin randomizer
        new Thread(() -> {
            for (int i = 0;; i++) {
                Station randOrigin = (Station) segments[new Random().nextInt(NUM_STATIONS) * 2 + 1];
                Station randDestination;

                do {
                    randDestination = (Station) segments[new Random().nextInt(NUM_STATIONS) * 2 + 1];
                } while (randDestination.equals(randOrigin));

                new Thread(new Passenger(Integer.toString(i), randOrigin, randDestination, this)).start();

                // Wait for at most 3 secs before generating another passenger
                sleep(new Random().nextInt(3000));
            }
        }).start();

        // Add 4 trains
        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);
        // Add 4 trains
        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);
        // Add 4 trains
        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);
        // Add 3 trains
        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);

        activateTrain(trains);
        sleep(2000);
    }

    // Set the train stations up
    public Segment[] setInfrastructure(int numStations) {
        // Create the segments
        Segment[] newSegments = new Segment[numStations * 2 + 1];

        for (int i = 0; i < newSegments.length - 1; i++) {
            if (i % 2 != 0) {
                newSegments[i] = new Station("Station " + (i / 2 + 1), i);
            } else {
                newSegments[i] = new FreeSegment(i);
            }
        }

        // Link the segments to form a circular linked list
        for (int i = 0; i < newSegments.length - 1; i++) {
            if (i > 0) {
                newSegments[i].setPrevSegment(newSegments[(i - 1) % (newSegments.length - 1)]);
            } else {
                newSegments[i].setPrevSegment(newSegments[newSegments.length - 2]);
            }

            newSegments[i].setNextSegment(newSegments[(i + 1) % (newSegments.length - 1)]);
        }

        // Configure the entry point branch (segment[16])
        newSegments[newSegments.length - 1] = new FreeSegment(newSegments.length - 1);
        Segment entryPoint = newSegments[newSegments.length - 1];
        entryPoint.setPrevSegment(null);
        entryPoint.setNextSegment(newSegments[0]);

        return newSegments;
    }

    // Set the train fleet up
    public Train[] setTrains(int maxTrains) {
        // Create the trains
        Train[] newTrains = new Train[maxTrains];

        for (int i = 0; i < newTrains.length; i++) {
            String color;

            switch (i % 3) {
                case 0:
                    color = "YELLOW";

                    break;
                case 1:
                    color = "ORANGE";

                    break;
                default:
                    color = "GREEN";

                    break;
            }

            newTrains[i] = new Train(i + 1, 100, (FreeSegment) segments[segments.length - 1], color, this);
            trainPositionMap.put(newTrains[i], null);
        }

        return newTrains;
    }

    // Make the fleet runnable
    public Thread[] prepareTrains() {
        Thread[] newTrains = new Thread[fleet.length];

        for (int i = 0; i < newTrains.length; i++) {
            newTrains[i] = new Thread(fleet[i]);
        }

        return newTrains;
    }

    // Activate a train for dispatch
    public void activateTrain(Thread[] trains) {
        trains[trainsDispatched++].start();
    }

    // Create a passenger
    public void createPassenger(String name, Station origin, Station destination) {
        new Thread(new Passenger(name, origin, destination, this)).start();
    }

    // Visualize the system
    public synchronized void visualize(boolean showMsgs) {
        if (!showMsgs) {
            // Header
            for (int i = 0; i < segments.length - 1; i++) {
                System.out.print((segments[i] instanceof Station)
                        ? "S" : "F");
            }

            System.out.println();

            for (int i = 1; i < segments.length - 1; i += 2) {
                System.out.print(" " + (i / 2 + 1));
            }

            System.out.println();

            for (int i = 0; i < segments.length - 1; i++) {
                System.out.print("=");
            }

            System.out.println();

            // Content
            for (int i = 0; i < segments.length - 1; i++) {
                // Free segment
                if (i % 2 == 0) {
                    System.out.print((segments[i].getTrainInside() != null)
                            ? Integer.toHexString(segments[i].getTrainInside().getNum()) : " ");
                } else {
                    // Station
                    System.out.print((segments[i].getTrainInside() != null)
                            ? Integer.toHexString(segments[i].getTrainInside().getNum()) : " ");
                }
            }

            System.out.println();

            for (int i = 0; i < segments.length * 2 - 1; i++) {
                System.out.print("=");
            }

            System.out.println();
        }
    }

    // Print a signal message
    public synchronized void print(String msg, boolean showMsgs) {
        if (showMsgs) {
            System.out.println(msg);
        }
    }

    // Update the visualization
    public void updateTrainPosition(Train train, Segment newLocation) {
        updateQueue.add(new TrainMoveSignal(train, newLocation));
    }

    // Pause the thread for n seconds
    public void sleep(int n) {
        try {
            Thread.sleep(n);
        } catch (InterruptedException ex) {
            System.out.println("Services interrupted.");
        }
    }
}
