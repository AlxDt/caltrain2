/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Core;

import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Station extends Segment implements Cloneable {

    // Core attributes
    private final String name;

    // Synchronization attributes
    private Station stationBoardLock;
    private Station stationAlightLock;

    // Constructor
    public Station(String name, int num) {
        super(num);

        this.name = name;

        try {
            // Create clones of this station for the passengers to wait on
            this.stationBoardLock = (Station) this.clone();
            this.stationAlightLock = (Station) this.clone();
        } catch (CloneNotSupportedException ex) {
            System.out.println("Cannot create a clone of this station.");

            this.stationBoardLock = null;
            this.stationAlightLock = null;
        }
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the stationBoardLock
     */
    public Station getStationBoardLock() {
        return stationBoardLock;
    }

    /**
     * @param stationBoardLock the stationBoardLock to set
     */
    public void setStationBoardLock(Station stationBoardLock) {
        this.stationBoardLock = stationBoardLock;
    }

    /**
     * @return the stationAlightLock
     */
    public Station getStationAlightLock() {
        return stationAlightLock;
    }

    /**
     * @param stationAlightLock the stationAlightLock to set
     */
    public void setStationAlightLock(Station stationAlightLock) {
        this.stationAlightLock = stationAlightLock;
    }

    // Get the station 
    public Station getStation(int steps) {
        Segment currSegment = this;

        for (int i = 1; i <= steps;) {
            currSegment = currSegment.getNextSegment();

            if (currSegment instanceof Station) {
                i++;
            }
        }

        return (Station) currSegment;
    }

    @Override
    public boolean equals(Object object) {
        return this.name.equals(((Station) object).getName());
    }

    @Override
    public int hashCode() {
        int hash = 5;

        hash = 17 * hash + Objects.hashCode(this.name);

        return hash;
    }
}
