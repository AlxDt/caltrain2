/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Core;

import Controller.CalTrain2;
import Model.Observer.TrainObserver;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Train implements Runnable {

    // Core attributes
    private final int num;
    private final int capacity;
    private final String color;

    // Link attributes
    private final FreeSegment entryPoint;
    private Segment currSegment;
    private Segment nextSegment;

    // Observers
    private final TrainObserver trainObserver;

    // Constructor
    public Train(int num, int capacity, FreeSegment entryPoint, String color, CalTrain2 dispatcher) {
        this.num = num;
        this.capacity = capacity;
        this.color = color;

        this.entryPoint = entryPoint;

        this.currSegment = entryPoint;
        this.nextSegment = currSegment.getNextSegment();

        this.trainObserver = new TrainObserver(dispatcher);
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @return the num
     */
    public int getNum() {
        return num;
    }

    /**
     * @return the capacity
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * @return the entryPoint
     */
    public FreeSegment getEntryPoint() {
        return entryPoint;
    }

    /**
     * @return the currSegment
     */
    public Segment getCurrSegment() {
        return currSegment;
    }

    /**
     * @param currSegment the currSegment to set
     */
    public void setCurrSegment(Segment currSegment) {
        this.currSegment = currSegment;
    }

    /**
     * @return the nextSegment
     */
    public Segment getNextSegment() {
        return nextSegment;
    }

    /**
     * @param nextSegment the nextSegment to set
     */
    public void setNextSegment(Segment nextSegment) {
        this.nextSegment = nextSegment;
    }

    // Move forward
    private void proceed() {
        // We've just moved to the next segment
        currSegment = nextSegment;
        nextSegment = currSegment.getNextSegment();
    }

    /**
     * @return the trainObserver
     */
    public TrainObserver getTrainObserver() {
        return trainObserver;
    }

    // Alight passengers
    private void alightPassengers(boolean showMsgs) {
        //print("Train #" + num + " is alighting passengers...", showMsgs);

        // This is the current station monitor
        // Notify the passengers that we're ready to take them out
        Station currentStationMonitor = ((Station) currSegment).getStationAlightLock();

        synchronized (currentStationMonitor) {
            currentStationMonitor.notifyAll();
        }

        // Then give passengers one second to get off
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            trainObserver.print("Services interrupted.", showMsgs);
        }
    }

    // Load passengers
    // station_load_train(struct station *station, int count)
    private void loadPassengers(boolean showMsgs) {
        //print("Train #" + num + " is boarding passengers...", showMsgs);

        // This is the current station monitor
        // Notify the passengers that we're ready to take them in
        Station currentStationMonitor = ((Station) currSegment).getStationBoardLock();

        synchronized (currentStationMonitor) {
            currentStationMonitor.notifyAll();
        }

        // Then give passengers one second to get on
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            trainObserver.print("Services interrupted.", showMsgs);
        }
    }

    // Pause the thread for n seconds
    public void sleep(int n, boolean showMsgs) {
        try {
            Thread.sleep(n);
        } catch (InterruptedException ex) {
            trainObserver.print("Services interrupted.", showMsgs);
        }
    }

    @Override
    public void run() {
        // Debug variable to use monitors or not
        boolean useMonitors = true;

        // Debug variable to show print statements (or not)
        boolean showMsgs = false;

        // Dispatch delay
        sleep(2000, showMsgs);

        // Use monitors or not?
        if (useMonitors) {
            runWithMonitors(showMsgs);
        } else {
            //runWithSempahores(showMsgs);
        }
    }

    // Run with monitors
    public void runWithMonitors(boolean showMsgs) {
        // This is the entry monitor
        Segment entryPointMonitor = entryPoint;

        synchronized (entryPointMonitor) {
            try {
                // Wait until the entry point branch is clear
                // This loop guards against spurious wakeups as recommended
                // by the official Java documentation
                while (entryPoint.isOccupied()) {
                    entryPointMonitor.wait();
                }

                // Take this spot
                entryPoint.setIsOccupied(true);
                entryPoint.setTrainInside(this);

                // The next segment monitor
                Segment nextSegmentMonitor = nextSegment;

                synchronized (nextSegmentMonitor) {
                    // Wait until the segment AFTER the entry point branch is unreserved
                    // This loop guards against spurious wakeups as recommended
                    // by the official Java documentation
                    while (nextSegment.isReserved()) {
                        nextSegmentMonitor.wait();
                    }

                    // Immediately claim the next segment
                    nextSegment.setIsReserved(true);
                }

                // Leave this spot
                entryPoint.setIsOccupied(false);
                entryPoint.setTrainInside(null);
            } catch (InterruptedException ex) {
                trainObserver.print("Services interrupted.", showMsgs);
            }

            // Enter the line!
            proceed();

            // Notify the trains that are waiting for this segment to be clear
            entryPointMonitor.notify();
        }

        // Run this code indefinitely
        while (true) {
            // This is the current segment monitor
            // Only one train can ever occupy this segment
            // Take note of the current segment
            Segment currSegmentMonitor = currSegment;

            synchronized (currSegmentMonitor) {
                // Take this spot
                currSegment.setIsOccupied(true);
                currSegment.setTrainInside(this);
                currSegment.setIsReserved(false);

                // Notify this train's observer that its position has changed
                // Console position update
                trainObserver.update(showMsgs);

                // GUI position update
                trainObserver.updateTrainPosition(this, currSegment);

                // If this segment is a station, load and unload passengers
                if (currSegment instanceof Station) {
                    // Open doors and allow passengers to get off and on
                    alightPassengers(showMsgs);
                    loadPassengers(showMsgs);
                } else {
                    // Else, take a second to move
                    sleep(1000, showMsgs);
                }

                // This is the next segment monitor
                Segment nextSegmentMonitor = nextSegment;

                synchronized (nextSegmentMonitor) {
                    // Is it okay to proceed?
                    try {
                        // Wait until the next segment is clear
                        // This loop guards against spurious wakeups as recommended
                        // by the official Java documentation
                        while (nextSegment.isReserved()) {
                            nextSegmentMonitor.wait();
                        }

                        // Immediately claim the next segment
                        nextSegment.setIsReserved(true);
                    } catch (InterruptedException ex) {
                        trainObserver.print("Services interrupted.", showMsgs);
                    }
                }

                // Leave this spot
                currSegment.setIsOccupied(false);
                currSegment.setTrainInside(null);

                // If ready, then proceed
                proceed();

                // Then tell others we're done occupying that spot
                currSegmentMonitor.notify();
            }
        }
    }

    // Run with semaphores
    public void runWithSempahores(boolean showMsgs) {
    }

    @Override
    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }

        return ((Train) object).num == this.num;
    }

    @Override
    public int hashCode() {
        int hash = 7;

        hash = 67 * hash + this.num;

        return hash;
    }
}
