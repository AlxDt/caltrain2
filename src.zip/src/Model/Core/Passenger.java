/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Core;

import Controller.CalTrain2;
import Model.Observer.PassengerObserver;

/**
 *
 * @author user
 */
public class Passenger implements Runnable {

    // Core attributes
    private final String name;
    private Station origin;
    private Station destination;
    private Status status;
    private Train currTrain;

    // Observers
    private final PassengerObserver passengerObserver;

    public enum Status {
        WAITING, BOARDING, SEATED, ALIGHTING, ARRIVED
    };

    // Constructor
    public Passenger(String name, Station origin, Station destination, CalTrain2 dispatcher) {
        this.name = name;
        this.origin = origin;
        this.destination = destination;
        this.status = Status.WAITING;
        this.currTrain = null;

        this.passengerObserver = new PassengerObserver(dispatcher);
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the origin
     */
    public Station getOrigin() {
        return origin;
    }

    /**
     * @param origin the origin to set
     */
    public void setOrigin(Station origin) {
        this.origin = origin;
    }

    /**
     * @return the destination
     */
    public Station getDestination() {
        return destination;
    }

    /**
     * @param destination the destination to set
     */
    public void setDestination(Station destination) {
        this.destination = destination;
    }

    /**
     * @return the status
     */
    public Status getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * @return the currTrain
     */
    public Train getCurrTrain() {
        return currTrain;
    }

    /**
     * @param currTrain the currTrain to set
     */
    public void setCurrTrain(Train currTrain) {
        this.currTrain = currTrain;
    }

    @Override
    public void run() {
        // Debug variable to use monitors or not
        boolean useMonitors = true;

        // Debug variable to show print statements (or not)
        boolean showMsgs = true;

        // Use monitors or not?
        if (useMonitors) {
            runWithMonitors(showMsgs);
        } else {
            //runWithSempahores(showMsgs);
        }
    }

    // Run with monitors
    public void runWithMonitors(boolean showMsgs) {
        // Is this passenger in his/her destination station?
        boolean isArrived = false;

        // Run this code indefinitely
        while (!isArrived) {
            // What the passenger does depends on his/her status
            switch (status) {
                case WAITING:
                    // Wait for the train
                    // This is the origin station monitor
                    Station originStationMonitor = origin.getStationBoardLock();

                    // station_wait_for_train(struct station *station)
                    synchronized (originStationMonitor) {
                        try {
                            passengerObserver.print("Passenger " + name + " is waiting at " + origin.getName(), showMsgs);

                            // Wait until the train is ready to pick the
                            // passengers up
                            // This loop guards against spurious wakeups as recommended
                            // by the official Java documentation
                            while (!origin.isOccupied()) {
                                originStationMonitor.wait();
                            }
                        } catch (InterruptedException ex) {
                            passengerObserver.print("Services interrupted.", showMsgs);
                        }
                    }

                    // Get ready to board!
                    status = Status.BOARDING;

                    break;
                case BOARDING:
                    // This is the time between the passengers waiting for the
                    // train and actually sitting down
                    // i.e., the passengers are in the process of boarding

                    // This passenger is now getting in the train
                    currTrain = origin.getTrainInside();

                    passengerObserver.print("Passenger " + name + " is boarding Train " + (currTrain.getNum() - 1), showMsgs);

                    // Just sit down
                    status = Status.SEATED;

                    break;
                case SEATED:
                    // Wait for the destination station
                    // This is the destination monitor
                    Station destinationStationMonitor = destination.getStationAlightLock();

                    synchronized (destinationStationMonitor) {
                        try {
                            passengerObserver.print("Passenger " + name + " is waiting for "
                                    + destination.getName() + " at Train " + (currTrain.getNum() - 1), showMsgs);

                            // Wait until the destination station is occupied
                            // and the train occupying it is the very train this
                            // passenger is on
                            // This loop guards against spurious wakeups as recommended
                            // by the official Java documentation
                            while (!destination.isOccupied() || !destination.getTrainInside().equals(currTrain)) {
                                destinationStationMonitor.wait();
                            }
                        } catch (InterruptedException ex) {
                            passengerObserver.print("Services interrupted.", showMsgs);
                        }
                    }

                    // If it is this station, get off!
                    status = Status.ALIGHTING;

                    break;
                case ALIGHTING:
                    passengerObserver.print("Passenger " + name + " is alighting from Train " + (currTrain.getNum() - 1), showMsgs);

                    // This passenger is now getting off the train
                    currTrain = null;

                    // We've arrived!
                    status = Status.ARRIVED;

                    break;
                case ARRIVED:
                    passengerObserver.print("Passenger " + name + " is done!", showMsgs);

                    // Get out because we're here and we're done!
                    isArrived = true;

                    break;
            }
        }
    }

    // Run with semaphores
    public void runWithSemaphores(boolean showMsgs) {

    }
}
