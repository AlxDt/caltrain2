/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Interface;

import Controller.CalTrain2;
import Controller.Listener;
import Model.Core.Segment;
import Model.Core.Train;
import Model.Sync.Signal;
import Model.Sync.TrainMoveSignal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author user
 */
public class UI extends Application {

    public static Stage window;
    public static Scene scene;

    public static final int WIDTH = 1000;
    public static final int HEIGHT = 600;

    // Create an update queue to listen for updates
    LinkedBlockingQueue updateQueue = new LinkedBlockingQueue();

    // Draw functions
    public static synchronized void drawBackground(GraphicsContext gc) {
        // Background
        gc.setFill(Color.LIGHTSTEELBLUE);
        gc.fillRect(0, 0, UI.WIDTH, UI.HEIGHT);

        // Segments
        gc.setStroke(Color.DARKGOLDENROD);
        gc.setLineWidth(5);

        // Segment 0 (entry point)
        gc.strokeLine(75, 225, 200, 125);

        // Segment 2
        gc.strokeLine(300, 125, 450, 125);

        // Segment 4
        gc.strokeLine(550, 125, 700, 125);

        // Segment 6
        gc.strokeLine(800, 125, 925, 225);

        // Segment 8
        gc.strokeLine(925, 325, 800, 425);

        // Segment 10
        gc.strokeLine(700, 425, 550, 425);

        // Segment 12
        gc.strokeLine(450, 425, 300, 425);

        // Segment 14
        gc.strokeLine(200, 425, 75, 325);

        // Stations
        gc.setFill(Color.ORANGE);

        // Station 1
        gc.fillRoundRect(200, 100, 100, 50, 25, 25);

        // Station 2
        gc.fillRoundRect(450, 100, 100, 50, 25, 25);

        // Station 3
        gc.fillRoundRect(700, 100, 100, 50, 25, 25);

        // Station 4
        gc.fillRoundRect(900, 225, 50, 100, 25, 25);

        // Station 5
        gc.fillRoundRect(200, 400, 100, 50, 25, 25);

        // Station 6
        gc.fillRoundRect(450, 400, 100, 50, 25, 25);

        // Station 7
        gc.fillRoundRect(700, 400, 100, 50, 25, 25);

        // Station 8
        gc.fillRoundRect(50, 225, 50, 100, 25, 25);
    }

    public static synchronized void redrawUI(GraphicsContext gc, HashMap<Train, Segment> trainPositionMap) {
        // Clear canvas
        gc.clearRect(0, 0, UI.WIDTH, UI.HEIGHT);

        // Draw the background (including the stations)
        drawBackground(gc);

        // Draw the trains corresponding to their position
        //gc.drawImage(new Image("/View/Res/Train.png"), new Random().nextInt(UI.WIDTH), new Random().nextInt(UI.HEIGHT));
        for (Map.Entry<Train, Segment> entry : trainPositionMap.entrySet()) {
            Train train = entry.getKey();
            Segment segment = entry.getValue();

            // If it's a null, draw nothing
            if (segment != null) {
                switch (((Segment) segment).getNum()) {
                    case 0:
                        gc.save();
                        gc.rotate(-38);

                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 137.5 - 185, 162.5 + 45);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 137.5 - 185, 162.5 + 45);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 137.5 - 185, 162.5 + 45);
                                break;
                        }

                        gc.restore();

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 120, 150);

                        break;
                    case 1:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 200, 110);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 200, 110);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 200, 110);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 200 + 47, 110 + 70);

                        break;
                    case 2:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 325, 110);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 325, 110);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 325, 110);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 325 + 47, 110 + 70);

                        break;
                    case 3:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 450, 110);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 450, 110);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 450, 110);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 450 + 47, 110 + 70);

                        break;
                    case 4:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 575, 110);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 575, 110);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 575, 110);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 575 + 47, 110 + 70);

                        break;
                    case 5:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 700, 110);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 700, 110);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 700, 110);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 700 + 47, 110 + 70);

                        break;
                    case 6:
                        gc.save();
                        gc.rotate(38);

                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 750 - 10, 500 - 910);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 750 - 10, 500 - 910);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 750 - 10, 500 - 910);
                                break;
                        }

                        gc.restore();

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 875, 150);

                        break;
                    case 7:
                        gc.save();
                        gc.rotate(90);

                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 225, -940);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 225, -940);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 225, -940);
                                break;
                        }

                        gc.restore();

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 960, 275);

                        break;
                    case 8:
                        gc.save();
                        gc.rotate(-38);

                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 400, 810);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 400, 810);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 400, 810);
                                break;
                        }

                        gc.restore();

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 875, 400);

                        break;
                    case 9:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 700, 410);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 700, 410);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 700, 410);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 700 + 47, 410 - 40);

                        break;
                    case 10:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 575, 410);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 575, 410);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 575, 410);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 575 + 47, 410 - 40);

                        break;
                    case 11:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 450, 410);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 450, 410);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 450, 410);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 450 + 47, 410 - 40);

                        break;
                    case 12:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 325, 410);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 325, 410);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 325, 410);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 325 + 47, 410 - 40);

                        break;
                    case 13:
                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 200, 410);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 200, 410);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 200, 410);
                                break;
                        }

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 200 + 47, 410 - 40);

                        break;
                    case 14:
                        gc.save();
                        gc.rotate(38);

                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), 300 - 10, 200 - 5);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), 300 - 10, 200 - 5);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), 300 - 10, 200 - 5);
                                break;
                        }

                        gc.restore();

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 120, 400);

                        break;
                    case 15:
                        gc.save();
                        gc.rotate(-90);

                        switch (train.getColor()) {
                            case "YELLOW":
                                gc.drawImage(new Image("/View/Res/Train.png"), -325, 60);
                                break;
                            case "ORANGE":
                                gc.drawImage(new Image("/View/Res/TrainOrange.png"), -325, 60 + 10);
                                break;
                            default:
                                gc.drawImage(new Image("/View/Res/TrainGreen.png"), -325, 60);
                                break;
                        }

                        gc.restore();

                        gc.setFill(Color.BLACK);
                        gc.fillText("" + train.getNum(), 35, 275);

                        break;
                }
            }
        }
    }

    public synchronized void updateTrainPosition(Train train, Segment newLocation) {

    }

    // Launchers
    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;

        // Root node
        Group root = new Group();

        // Canvas for drawing
        Canvas canvas = new Canvas(UI.WIDTH, UI.HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // Initially redraw the UI
        redrawUI(gc, CalTrain2.trainPositionMap);

        // Window configuration
        scene = new Scene(root);

        root.getChildren().add(canvas);

        window.setScene(scene);
        window.setTitle("CalTrain II");
        window.setHeight(UI.HEIGHT);
        window.setWidth(UI.WIDTH);
        window.setResizable(false);
        window.show();

        window.setOnCloseRequest(e -> {
            System.exit(0);
        });

        // MAIN ENTRY POINT //
        // Start the controller in a separate thread
        // to avoid choking the UI thread
        new Thread(() -> {
            new CalTrain2(updateQueue).start();
        }).start();

        // UPDATE LISTENERS //
        // Train update listener
        Listener.trainListener(this, gc, updateQueue);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
